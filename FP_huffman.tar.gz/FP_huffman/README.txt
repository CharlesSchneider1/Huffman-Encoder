Charlie Schneider and Jeffrey Fix
CS270 Final
Huffman Tree

To the best of our knowledge, all parts of the program are working properly. In our main file, we have individual test functions for the different parts as well as a user interface function. In order to decode, you must have the tree saved as "decodethis.txt". In our example, we encode the string "decoder" to the file "finalEncoding.txt", and then we decode the stream associated with that encoding to "finalDecoding.txt" using the tree saved in "decodethis.txt". 
